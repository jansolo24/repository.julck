# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m):
 import xbmc
 import xbmcaddon
 addon = xbmcaddon.Addon('plugin.video.cristalazul')
 Url = 'link[::4] + url[:8] + Creditos[62:] = http://bit.ly/sourcecristalazul'
 grupotelegram = 'http://web.telegram.org/@addonfesta'
 url = 'cristal_azul_fue_creado_por_el_grupo_festa_para_el_disfrute_en familia, este_addon_es_completamente_gratuito,disfrute_de_la_seccion_de_Acestream_creada_por_Acestream_Spanish'
 Creditos = 'Acestream_league_para_todos_gratuita_creada_por_Supertopo_del_grupo_cristal_azul'
 info = 'british.true.Build.py %7/'
 return  grupotelegram[:7] + info[::4] + url[:7] + Creditos[:10] + url[156:]
def revist_dag(page_data):
    final_url = ''
    if '127.0.0.1' in page_data:
        final_url = re_me(page_data, '&ver_t=([^&]+)&') + ' live=true timeout=15 playpath=' + re_me(page_data, '\\?y=([a-zA-Z0-9-_\\.@]+)')

    if re_me(page_data, 'token=([^&]+)&') != '':
        final_url = final_url + '?token=' + re_me(page_data, 'token=([^&]+)&')
    elif re_me(page_data, 'wmsAuthSign%3D([^%&]+)') != '':
        final_url = re_me(page_data, '&ver_t=([^&]+)&') + '?wmsAuthSign=' + re_me(page_data, 'wmsAuthSign%3D([^%&]+)') + '==/mp4:' + re_me(page_data, '\\?y=([^&]+)&')
    else:
        final_url = re_me(page_data, 'HREF="([^"]+)"')

    if 'dag1.asx' in final_url:
        return get_dag_url(final_url)

    if 'devinlivefs.fplive.net' not in final_url:
        final_url = final_url.replace('devinlive', 'flive')
    if 'permlivefs.fplive.net' not in final_url:
        final_url = final_url.replace('permlive', 'flive')
    return ''
