# -*- coding: utf-8 -*-

from core import httptools, scrapertools
from platformcode import logger
from lib import jsunpack

CUSTOM_HEADERS = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0', 'Referer': 'http://gamovideo.com'}

def normalizar_url(page_url):
    if 'embed' in page_url:
        vid = scrapertools.find_single_match(page_url, "gamovideo.com/(?:embed-|)([a-z0-9]+)")
        return "http://gamovideo.com/" + vid
    return page_url


def test_video_exists(page_url):
    logger.info("(page_url='%s')" % page_url)

    page_url = normalizar_url(page_url)

    # Provocar una primera llamada aunque devuelva un 404 crea las cookies necesarias
    data = httptools.downloadpage(page_url, headers=CUSTOM_HEADERS).data
    # ~ logger.debug(data)

    # ~ packer = scrapertools.find_single_match(data, "<script type='text/javascript'>(eval.function.p,a,c,k,e,d..*?)</script>")
    # ~ if packer == '':
        # ~ return False, "[Gamovideo] El archivo no está disponible."
    return True, ""


def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    logger.info("(page_url='%s')" % page_url)
    video_urls = []
    
    page_url = normalizar_url(page_url)
    
    data = httptools.downloadpage(page_url, headers=CUSTOM_HEADERS).data
    # ~ logger.debug(data)

    packer = scrapertools.find_single_match(data, "<script type='text/javascript'>(eval.function.p,a,c,k,e,d..*?)</script>")
    if packer != "":
        data = jsunpack.unpack(packer)
        # ~ logger.debug(data)

    mp4 = scrapertools.find_single_match(data, ',\{file\s*:\s*"([^"]+)')
    if mp4: video_urls.append(["mp4 [gamovideo]", mp4])

    return video_urls
