# -*- coding: utf-8 -*-

from core import httptools, scrapertools
from platformcode import logger

def test_video_exists(page_url):
    logger.info("(page_url='%s')" % page_url)
    data = httptools.downloadpage(page_url).data
    if "file can't be found" in data:
        return False, "[Jetload] El fichero no existe o ha sido borrado"
    return True, ""


def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    logger.info("url=" + page_url)
    video_urls = []

    data = httptools.downloadpage(page_url).data
    # ~ logger.debug(data)
    
    srv = scrapertools.find_single_match(data, 'id="srv" value="([^"]+)"')
    file_name = scrapertools.find_single_match(data, 'id="file_name" value="([^"]+)"')

    file_low = scrapertools.find_single_match(data, 'id="file_low" value="([^"]+)"')
    file_med = scrapertools.find_single_match(data, 'id="file_med" value="([^"]+)"')
    file_high = scrapertools.find_single_match(data, 'id="file_high" value="([^"]+)"')
    
    url = srv + '/v2/schema/' + file_name

    if file_low == '1': video_urls.append(['low', url + '/low.m3u8'])
    if file_med == '1': video_urls.append(['medium', url + '/med.m3u8'])
    if file_high == '1': video_urls.append(['high', url + '/high.m3u8'])

    return video_urls
