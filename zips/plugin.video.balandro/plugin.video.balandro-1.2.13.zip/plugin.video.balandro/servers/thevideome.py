# -*- coding: utf-8 -*-

server = 'vevio'
server_module = __import__('servers.%s' % server, None, None, ["servers.%s" % server])

def modificar_page_url(page_url):
    try:
        from core import httptools
        return httptools.downloadpage(page_url, only_headers=True, follow_redirects=False).headers.get('location')
    except:
        return page_url.replace('embed-', '').replace('.html', '').replace('thevideo.me/', 'vev.io/')
    
def get_video_url(page_url, url_referer=''):
    return server_module.get_video_url(modificar_page_url(page_url))

