# -*- coding: utf-8 -*-

from core import httptools, scrapertools
from platformcode import logger, platformtools
import urllib


def get_video_url(page_url, url_referer=''):
    logger.info("url=" + page_url)
    video_urls = []

    # ~ codigo = scrapertools.find_single_match(page_url, "/([A-z0-9]+)$")
    # ~ data = httptools.downloadpage("https://vev.io/embed/" + codigo).data
    # ~ logger.debug(data)

    post = {}
    post = urllib.urlencode(post)

    codigo = scrapertools.find_single_match(page_url, "/([A-z0-9]+)$")
    url = "https://vev.io/api/serve/video/" + codigo
    
    data = httptools.downloadpage(url, post=urllib.urlencode(post)).data
    # ~ logger.debug(data)

    # ~ https://www.google.com/recaptcha/api2/reload?k=6Ld6RqIUAAAAAKjcjfIgh2TmF_HmAc5hvrQx_D9a
    if 'qualities":' not in data: #TODO?
        sitekey = '6Ld6RqIUAAAAAKjcjfIgh2TmF_HmAc5hvrQx_D9a' #scrapertools.find_single_match(data, "'sitekey' : '([^']+)'")
        gresponse = platformtools.dialog_recaptcha(sitekey, page_url)
        if gresponse != '':
            post['g-recaptcha-verify'] = gresponse
            data = httptools.downloadpage(url, post=urllib.urlencode(post)).data
            # ~ logger.debug(data)
            # ~ codigo_js = scrapertools.find_multiple_matches(data, '<script>document.write\(unescape\("([^"]+)')
            # ~ logger.debug(codigo_js)

 
    bloque = scrapertools.find_single_match(data, 'qualities":\{(.*?)\}')
    matches = scrapertools.find_multiple_matches(bloque, '"([^"]+)":"([^"]+)')
    for res, media_url in matches:
        video_urls.append([scrapertools.get_filename_from_url(media_url)[-4:] + " (" + res + ")", media_url])

    return video_urls
