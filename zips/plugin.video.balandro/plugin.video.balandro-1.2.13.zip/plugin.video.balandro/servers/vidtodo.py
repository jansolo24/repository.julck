# -*- coding: utf-8 -*-

from core import httptools, scrapertools
from platformcode import logger


def get_video_url(page_url, url_referer=''):
    logger.info("url=" + page_url)
    video_urls = []

    data = httptools.downloadpage(page_url).data
    # ~ logger.debug(data)

    if '<b>File Not Found</b>' in data or 'The file was deleted by' in data or data == '':
        return 'El fichero no existe o ha sido borrado'
    
    matches = scrapertools.find_multiple_matches(data, 'file\s*:\s*"([^"]+)"\s*,\s*label\s*:\s*"([^"]+)"')
    if matches:
        for url, lbl in matches:
            if url.endswith('.srt'): continue
            video_urls.append([lbl, url])
    else:
        matches = scrapertools.find_multiple_matches(data, 'file\s*:\s*"([^"]+)"')
        for url in matches:
            if url.endswith('.srt'): continue
            video_urls.append(['mp4', url])

    return video_urls
