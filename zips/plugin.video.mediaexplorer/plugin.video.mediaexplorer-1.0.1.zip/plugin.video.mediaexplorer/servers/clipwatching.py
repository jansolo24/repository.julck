# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    videos = scrapertools.find_multiple_matches(data, '{file:"([^"]+)",label:"([^"]+)"}')

    for url, res in videos:
        itemlist.append(Video(url=url, res=res))

    return itemlist
