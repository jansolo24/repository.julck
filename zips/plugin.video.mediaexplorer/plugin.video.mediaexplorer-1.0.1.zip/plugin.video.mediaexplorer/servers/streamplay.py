# -*- coding: utf-8 -*-

import base64

from core.libs import *
from lib import jsunpack


def get_video_url(item):
    logger.trace()
    itemlist = []

    referer = re.sub(r"embed-|player-", "", item.url)[:-5]

    data = httptools.downloadpage(item.url, headers={'Referer': referer}).data

    if data == "File was deleted":
        return "El archivo no existe o ha sido borrado"

    packed = scrapertools.find_single_match(data, "<script type=[\"']text/javascript[\"']>(eval.*?)</script>")
    unpacked = jsunpack.unpack(packed)

    url = scrapertools.find_single_match(unpacked, '(http[^,]+\.mp4)')
    itemlist.append(Video(url=decode_video_url(url)))

    return itemlist

def decode_video_url(url):
    tria = re.compile('[0-9a-z]{40,}', re.IGNORECASE).findall(url)[0]
    gira = tria[::-1]
    x = gira[:2] + gira[3:]

    return re.sub(tria, x, url)