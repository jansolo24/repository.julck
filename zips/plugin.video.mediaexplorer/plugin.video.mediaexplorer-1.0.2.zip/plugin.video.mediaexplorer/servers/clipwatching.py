# -*- coding: utf-8 -*-
from core.libs import *
from lib import jsunpack


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    unpacked = jsunpack.unpack(scrapertools.find_single_match(data, "<script type=.text/javascript.>(eval.*?)</script>"))

    videos = scrapertools.find_multiple_matches(unpacked, '{file:"([^"]+)",label:"([^"]+)"}')

    for url, res in videos:
        itemlist.append(Video(url=url, res=res))

    return itemlist
