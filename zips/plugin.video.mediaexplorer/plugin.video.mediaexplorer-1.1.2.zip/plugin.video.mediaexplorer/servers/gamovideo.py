# -*- coding: utf-8 -*-
from core.libs import *
import js2py


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url, headers={"Cookie": "gam=1", "Referer":item.url.replace('embed-','')}).data

    if 'File was deleted' in data or 'File was locked by administrator' in data:
        return ResolveError(0)
    elif 'Video is processing now' in data:
        return ResolveError(1)
    elif "File is awaiting for moderation" in data:
        return ResolveError(1)
    elif 'Video encoding error' in data:
        return ResolveError(5)

    unpacked = js2py.eval_js(scrapertools.find_single_match(data, "<script type=.text/javascript.>eval(.*?)</script>"))

    itemlist.append(Video(url=scrapertools.find_single_match(unpacked, 'file:"([^"]+v.mp4)"')))

    rtmp_url,playpath = scrapertools.find_single_match(unpacked, 'file:"(rtmp://.*?)/(mp4:[^"]+)"')
    itemlist.append(Video(url=rtmp_url + "/ playpath=" + playpath + " swfUrl=http://gamovideo.com/player61/jwplayer.flash.swf"))

    return itemlist
