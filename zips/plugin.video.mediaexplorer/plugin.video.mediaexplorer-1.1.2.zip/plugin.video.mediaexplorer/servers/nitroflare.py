# -*- coding: utf-8 -*-
from core.libs import *
# TODO: No permite descarga rapida sin una cuenta premium


def get_video_url(item):
    logger.trace()
    itemlist = list()

    return
